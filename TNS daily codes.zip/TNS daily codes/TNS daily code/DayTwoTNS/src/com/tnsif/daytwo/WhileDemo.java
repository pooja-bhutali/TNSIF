package com.tnsif.daytwo;

public class WhileDemo {

	public static void main(String[] args) {
		
     int i=1;
     while(i<=50)
     {
    	 System.out.println("Value of i = "+i);
    	// i++;
     }
	}

}


//while(condition)
//{
//	//code
//}