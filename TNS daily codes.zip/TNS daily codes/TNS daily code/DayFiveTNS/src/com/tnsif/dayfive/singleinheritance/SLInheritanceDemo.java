package com.tnsif.dayfive.singleinheritance;

public class SLInheritanceDemo {

	public static void main(String[] args) {
	
		Student st = new Student("Gaytri", "808080808080","Pune", "7867564534",10, "G.H.Raisoni");
		System.out.println(st);

	}

}
