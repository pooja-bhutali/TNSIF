package com.tnsif.nestedinterfacedemo;

public class Driver {

	public static void main(String[] args) {
		
		NestedInterface obj = new NestedInterface();
		obj.disp();
		

	}

}
