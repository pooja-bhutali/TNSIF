package com.tnsif.dayeight.interfacedemo;

public interface ChildInterface extends ParentInterface{
	
	void display();
  
}
