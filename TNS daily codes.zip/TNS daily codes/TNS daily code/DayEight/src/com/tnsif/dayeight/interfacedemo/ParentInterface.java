package com.tnsif.dayeight.interfacedemo;

public interface ParentInterface {
	
	void show();
	
	 static void data()
	{
		
	}
	 
	 void addition();
	 
	 void sum();
	
	
	
	
}
