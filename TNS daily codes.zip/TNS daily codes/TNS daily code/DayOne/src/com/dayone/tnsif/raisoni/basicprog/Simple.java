package com.dayone.tnsif.raisoni.basicprog;

public class Simple {

	public static void main(String args[])
			{
		
		System.out.println("Hello World");
		
		System.out.print("Hello Students");
			}
	
}


