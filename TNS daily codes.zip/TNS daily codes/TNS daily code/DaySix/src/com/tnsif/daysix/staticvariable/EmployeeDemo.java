package com.tnsif.daysix.staticvariable;

public class EmployeeDemo {

	public static void main(String[] args) {
		
		Employee e = new Employee("Siddhi", 101);
		System.out.println(e);
		
		Employee e1 = new Employee("Vikas", 102);
		System.out.println(e1);

	}

}
