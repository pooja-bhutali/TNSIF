package com.tnsif.daythree.encapsulation;

public class EncapsulationDemo {

	public static void main(String[] args) {
		
		OopsConceptDemo obj = new OopsConceptDemo();
		
		obj.setSerialNum(101);
		obj.setName("Rekha");
		obj.setAge(21);
		
		System.out.println(obj);

	}

}
